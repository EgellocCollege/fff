<?php

	$tmp= strtolower(preg_replace('/:.*$/', '',  $_SERVER["HTTP_HOST"]));
	if ( $tmp != 'localhost' && $tmp != $_SERVER['SERVER_ADDR'] )
		$tmp = 'www.' . str_replace('www.', '', $tmp);
	$domain = $tmp;
	$root = str_replace('\\','/',realpath(dirname(__FILE__).'/../').'/');
	$site = str_replace(str_replace('\\','/',realpath($_SERVER['DOCUMENT_ROOT'])), '', $root );
	$siteurl = 'http://' . $domain . $site;


	$expiresOffset = 864000; // 10 days
	header( "Content-Type: text/javascript; charset=utf-8" );
	header( "Vary: Accept-Encoding" ); // Handle proxies
	header( "Expires: " . gmdate( "D, d M Y H:i:s", time() + $expiresOffset ) . " GMT" );

	echo "var site_url = '$siteurl';";
